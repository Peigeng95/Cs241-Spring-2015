#include "kind.h"
#include "lexer.h"
#include <vector>
#include <string>
#include <iostream>
// Use only the neeeded aspects of each namespace
using std::string;
using std::vector;
using std::endl;
using std::cerr;
using std::cin;
using std::getline;
using ASM::Token;
using ASM::Lexer;

class Label{
	string label;
	unsigned int address;
	public:
	void setLabel(string l){
		label = l;
	}
	void setAddress(unsigned int a){
		address = a;
	}
	string getLabel(){
		return label;
	}
	unsigned int getAddr(){
		return address;
	}
};

int main(int argc, char* argv[]){
  // Nested vector representing lines of Tokens
  // Needs to be used here to cleanup in the case
  // of an exception
  vector< vector<Token*> > tokLines;

//address recording for beq and bne
	vector <int> tokenaddr; 
  try{
    // Create a MIPS recognizer to tokenize
    // the input lines
    Lexer lexer;
    // Tokenize each line of the input
    string line;
	 int commandline=0;
	 int address=0;
	 vector<Label> labellist;
    while(getline(cin,line)){
    	tokLines.push_back(lexer.scan(line));
		if(tokLines[commandline].size() == 0){
			tokLines.pop_back();		
			continue;
		}
	   int numberoflabel=0;
		while (tokLines[commandline][numberoflabel]->getKind() == ASM::LABEL) {
			string label = tokLines[commandline][numberoflabel]->getLexeme();
			label.erase(label.length()-1);//erase:
			if (labellist.size() != 0) {
				for (int i = 0; i < labellist.size(); i++) {
					if (label == labellist[i].getLabel()) {
						string error = "ERROR: Label already exist";
						throw error;
						break;
					}
				}	
			}
			Label lab;
			lab.setLabel(label);
			lab.setAddress(address * 4);
			labellist.push_back(lab);
			cerr << label << " " << lab.getAddr() << endl;
			numberoflabel++;
			if (tokLines[commandline].size() == numberoflabel){
				break;
			}
		}
		if(tokLines[commandline].size() == numberoflabel){
			tokLines.pop_back();
			tokenaddr.push_back(0);
			continue;
		}
		if(tokLines[commandline].size() == 1+numberoflabel){
			string error = "ERROR : expect some arguments";
			throw error;
		}
		tokenaddr.push_back(address);
		address++;
		commandline++;
    }

	for(int i=0; i<tokLines.size(); i++){
		int token=0;
		while (tokLines[i][token]->getKind() == ASM::LABEL) {
			token++;
			if (tokLines[i].size() == token){
				break;
			}
		}
		if (tokLines[i].size() == token){
			continue;
		}
		unsigned int add = 0;
		bool success = false;
		string function = tokLines[i][token]->getLexeme();

		if (function == ".word"){
			if (tokLines[i][token+1]->getKind() == ASM::REGISTER) {
				string error = "ERROR: Only int value is valid after .word";
				throw error;
			}
			if (tokLines[i].size() != token+2) {
				string error = "ERROR : .word expect 2 parts";
				throw error;
			}
			if (tokLines[i][token+1]->getKind() == ASM::ID){
				for (int j = 0; j < labellist.size(); j++) {
					string label = tokLines[i][token+1]->getLexeme();
					if (label == labellist[j].getLabel()) {
						add = labellist[j].getAddr();
						success = true;
						break;
					}
				}
				if (success == false) {
					string error = "ERROR: Label doesn't exit";
					throw error;
				}
			}
			else {
			add = tokLines[i][token+1]->toInt();
			}
			unsigned char c;
			c = add >> 24;
			std::cout << c;
			c = add >> 16;
			std::cout << c;
			c = add >> 8;
			std::cout << c;
	 		c = add;
	 		std::cout << c;
		}
		else if (function == "jr") {
			if (tokLines[i][token+1]->getKind() != ASM::REGISTER) {
				string error = "ERROR: Only register # are valid after jr";
				throw error;
			}			
			if (tokLines[i].size() != token+2) {
				string error = "ERROR: jr expect two parts.";
				throw error;
			}
			unsigned int regist = tokLines[i][token+1]->toInt();
			add = (0 << 26) | (regist << 21) | (8);
			unsigned char c;
			c = add >> 24;
			std::cout << c;
			c = add >> 16;
			std::cout << c;
			c = add >> 8;
			std::cout << c;
 			c = add;
 			std::cout << c;
		}
		else if (function == "jalr"){
			if (tokLines[i].size() != token+2) {
				string error = "ERROR: jalr expect two part";
				throw error;
			}
			if (tokLines[i][token+1]->getKind() != ASM::REGISTER) {
				string error = "ERROR: Only register # are valid after jalr";
				throw error;
			}
			unsigned int regist = tokLines[i][token+1]->toInt();
			add = (0 << 26) | (regist << 21) | (9);
			unsigned char c;
			c = add >> 24;
			std::cout << c;
			c = add >> 16;
			std::cout << c;
			c = add >> 8;
			std::cout << c;
 			c = add;
 			std::cout << c;
		}
		else if (function == "add"){
			if (tokLines[i].size() != token+6) {
				string error = "ERROR: add expect three part";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER) && (tokLines[i][token+4]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+5]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				unsigned int regist3 = tokLines[i][token+5]->toInt();
				add = (0 << 26) | (regist2 << 21) | (regist3 << 16) | (regist1 << 11) | (32);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
	 			c = add;
	 			std::cout << c;
			}
			else{
				string error = "ERROR: calling add with wrong peremeter";
				throw error;
			}
		}
		else if (function == "sub"){
			if (tokLines[i].size() != token+6) {
				string error = "ERROR: sub expect three part";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER) && (tokLines[i][token+4]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+5]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				unsigned int regist3 = tokLines[i][token+5]->toInt();
				add = (0 << 26) | (regist2 << 21) | (regist3 << 16) | (regist1 << 11) | (34);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
	 			c = add;
	 			std::cout << c;
			}
			else{
				string error = "ERROR: calling sub with wrong peremeter";
				throw error;
			}
		}
		else if (function == "slt"){
			if (tokLines[i].size() != token+6) {
				string error = "ERROR: slt expect three part";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER) && (tokLines[i][token+4]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+5]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				unsigned int regist3 = tokLines[i][token+5]->toInt();
				add = (0 << 26) | (regist2 << 21) | (regist3 << 16) | (regist1 << 11) | (42);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
	 			c = add;
	 			std::cout << c;
			}
			else{
				string error = "ERROR: calling slt with wrong peremeter";
				throw error;
			}
		}
		else if (function == "sltu"){
			if (tokLines[i].size() != token+6) {
				string error = "ERROR: sltu expect three part";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER) && (tokLines[i][token+4]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+5]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				unsigned int regist3 = tokLines[i][token+5]->toInt();
				add = (0 << 26) | (regist2 << 21) | (regist3 << 16) | (regist1 << 11) | (43);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
	 			c = add;
	 			std::cout << c;
			}
			else{
				string error = "ERROR: calling sltu with wrong peremeter";
				throw error;
			}
		}
		else if (function == "bne"){
			if (tokLines[i].size() != token+6) {
				string error = "ERROR: bne expect three part";
				throw error;
			}
			if((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER) &&(tokLines[i][token+4]->getKind() == ASM::COMMA)){
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				int jump;
				if (tokLines[i][token+5]->getKind() == ASM::INT) {
					jump = tokLines[i][token+5]->toInt();
					if ((jump >= 32768) || (jump < -32768)) {
						string error = "ERROR: jumping address out of range";
						throw error;
					}
					add = (5 << 26) | (regist1 << 21) | (regist2 << 16) | (jump&0xffff);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
	 				c = add;
	 				std::cout << c;
				}
				else if (tokLines[i][token+5]->getKind() == ASM::HEXINT) {
					unsigned int hexjump = tokLines[i][token+5]->toInt();
					if (hexjump > 0xffff){
						string error = "ERROR: jumping address out of range(Hex)";
						throw error;	
}
					add = (5 << 26) | (regist1 << 21) | (regist2 << 16) | (hexjump);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
	 				c = add;
	 				std::cout << c;
				}
				else if (tokLines[i][token+5]->getKind() == ASM::ID) {
					int jump = 0;
					for (int j = 0; j < labellist.size(); j++) {
						string label = tokLines[i][token+5]->getLexeme();
						if (label == labellist[j].getLabel()) {
							jump = labellist[j].getAddr();
							success = true;
							break;
						}
					}
					if (success == false) {
						string error = "ERROR: Label doesn't exist";
						throw error;
					}
					jump = jump / 4 - tokenaddr[i] - 1;
					if ((jump >= 32768) || (jump < -32768)) {
						string error = "ERROR: jumping address out of range";
						throw error;
					}
					add = (5 << 26) | (regist1 << 21) | (regist2 << 16) | (jump&0xffff);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
	 				c = add;
	 				std::cout << c;
				}	
				else {
					string error = "ERROR : expect int or hex num at the last position";
					throw error;
				}
			}
			else {
				string error = "ERROR: calling bne with wrong peremeter";
				throw error;
			}
		} 
		else if (function == "beq"){
			if (tokLines[i].size() != token+6) {
				string error = "ERROR: beq expect three part";
				throw error;
			}
			if((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER) &&(tokLines[i][token+4]->getKind() == ASM::COMMA)){
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				int jump;
				if (tokLines[i][token+5]->getKind() == ASM::INT) {
					jump = tokLines[i][token+5]->toInt();
					if ((jump >= 32768) || (jump < -32768)) {
						string error = "ERROR: jumping address out of range";
						throw error;
					}
					add = (4 << 26) | (regist1 << 21) | (regist2 << 16) | (jump&0xffff);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
	 				c = add;
	 				std::cout << c;
				}
				else if (tokLines[i][token+5]->getKind() == ASM::HEXINT) {
					unsigned int hexjump = tokLines[i][token+5]->toInt();
					if (hexjump > 0xffff){
						string error = "ERROR: jumping address out of range(Hex)";
						throw error;	
}
					add = (4 << 26) | (regist1 << 21) | (regist2 << 16) | (hexjump);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
	 				c = add;
	 				std::cout << c;
				}
				else if (tokLines[i][token+5]->getKind() == ASM::ID) {
					int jump = 0;
					for (int j = 0; j < labellist.size(); j++) {
						string label = tokLines[i][token+5]->getLexeme();
						if (label == labellist[j].getLabel()) {
							jump = labellist[j].getAddr();
							success = true;
							break;
						}
					}
					if (success == false) {
						string error = "ERROR: Label doesn't exist";
						throw error;
					}
					jump = jump / 4 - tokenaddr[i] - 1;
					if ((jump >= 32768) || (jump < -32768)) {
						string error = "ERROR: jumping address out of range";
						throw error;
					}
					add = (4 << 26) | (regist1 << 21) | (regist2 << 16) | (jump&0xffff);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
	 				c = add;
	 				std::cout << c;
				}	
				else {
					string error = "ERROR : expect int or hex num at the last position";
					throw error;
				}
			}
			else {
				string error = "ERROR: calling beq with wrong peremeter";
				throw error;
			}
		} 
		else if (function == "mfhi") {
			if (tokLines[i].size() != token+2) {
				string error = "ERROR: mfhi expect two arguments";
				throw error;
			}
			if (tokLines[i][token+1]->getKind() != ASM::REGISTER) {
				string error = "ERROR: mfhi expect register as second argument";
				throw error;
			}
			unsigned int regist1 = tokLines[i][token+1]->toInt();
			add = (0 << 16) | (regist1 << 11) | (16);
			unsigned char c;
			c = add >> 24;
			std::cout << c;
			c = add >> 16;
			std::cout << c;
			c = add >> 8;
			std::cout << c;
			c = add;
			std::cout << c;
		}
		else if (function == "mflo") {
			if (tokLines[i].size() != token+2) {
				string error = "ERROR: mflo expect two arguments";
				throw error;
			}
			if (tokLines[i][token+1]->getKind() != ASM::REGISTER) {
				string error = "ERROR: mflo expect register as second argument";
				throw error;
			}
			unsigned int regist1 = tokLines[i][token+1]->toInt();
			add = (0 << 16) | (regist1 << 11) | (18);
			unsigned char c;
			c = add >> 24;
			std::cout << c;
			c = add >> 16;
			std::cout << c;
			c = add >> 8;
			std::cout << c;
			c = add;
			std::cout << c;
		}
		else if (function == "lis") {
			if (tokLines[i].size() != token+2) {
				string error = "ERROR: lis expect two arguments";
				throw error;
			}
			if (tokLines[i][token+1]->getKind() != ASM::REGISTER) {
				string error = "ERROR: lis expect register as second argument";
				throw error;
			}
			unsigned int regist1 = tokLines[i][token+1]->toInt();
			add = (0 << 16) | (regist1 << 11) | (20);
			unsigned char c;
			c = add >> 24;
			std::cout << c;
			c = add >> 16;
			std::cout << c;
			c = add >> 8;
			std::cout << c;
			c = add;
			std::cout << c;
		}		

		else if (function == "mult") {
			if (tokLines[i].size() != token+4) {
				string error = "ERROR: mult expect two arguments";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				add = (0 << 26) | (regist1 << 21) | (regist2 << 16) | (24);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
				c = add;
				std::cout << c;
			}
			else{
				string error = "ERROR: mult expect register as arguments";
				throw error;
			}
		}

		else if (function == "multu") {
			if (tokLines[i].size() != token+4) {
				string error = "ERROR: multu expect two arguments";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				add = (0 << 26) | (regist1 << 21) | (regist2 << 16) | (25);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
				c = add;
				std::cout << c;
			}
			else{
				string error = "ERROR: multu expect register as arguments";
				throw error;
			}
		}

		else if (function == "div") {
			if (tokLines[i].size() != token+4) {
				string error = "ERROR: div expect two arguments";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				add = (0 << 26) | (regist1 << 21) | (regist2 << 16) | (26);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
				c = add;
				std::cout << c;
			}
			else{
				string error = "ERROR: div expect register as arguments";
				throw error;
			}
		}	

		else if (function == "divu") {
			if (tokLines[i].size() != token+4) {
				string error = "ERROR: divu expect two arguments";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() == ASM::REGISTER) && (tokLines[i][token+2]->getKind() == ASM::COMMA) &&
			    (tokLines[i][token+3]->getKind() == ASM::REGISTER)) {
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+3]->toInt();
				add = (0 << 26) | (regist1 << 21) | (regist2 << 16) | (27);
				unsigned char c;
				c = add >> 24;
				std::cout << c;
				c = add >> 16;
				std::cout << c;
				c = add >> 8;
				std::cout << c;
				c = add;
				std::cout << c;
			}
			else{
				string error = "ERROR: divu expect register as arguments";
				throw error;
			}
		}	

		else if (function == "lw") {
			if (tokLines[i].size() != token+7) {
				string error = "ERROR: lw expect three arguments";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() != ASM::REGISTER) || (tokLines[i][token+2]->getKind() != ASM::COMMA) ||
			    ((tokLines[i][token+3]->getKind() != ASM::INT) && (tokLines[i][token+3]->getKind() != ASM::HEXINT)) ||
			    (tokLines[i][token+4]->getKind() != ASM::LPAREN) || (tokLines[i][token+5]->getKind() != ASM::REGISTER) ||
			    (tokLines[i][token+6]->getKind() != ASM::RPAREN)){
				string error = "ERROR: calling lw with wrong peremeter";
				throw error;
			}
			else{	
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+5]->toInt();
				int num;
				unsigned int hexnum;
				if (tokLines[i][token+3]->getKind() == ASM::INT) {
					num = tokLines[i][token+3]->toInt();
					if ((num > 32769) || (num < -32768)) {
						string error = "ERROR: out of range";
						throw error;
					}
					add = (35 << 26) | (regist2 << 21) | (regist1 << 16) | (num&0xffff);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
					c = add;
					std::cout << c;
				}
				else if (tokLines[i][token+3]->getKind() == ASM::HEXINT) {
					hexnum = tokLines[i][token+3]->toInt();
					if (hexnum > 0xffff){
						string error = "ERROR: out of range";
						throw error;
					}
					add = (35 << 26) | (regist2 << 21) | (regist1 << 16) | (hexnum);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
					c = add;
					std::cout << c;
				}
			}
		}


		else if (function == "sw") {
			if (tokLines[i].size() != token+7) {
				string error = "ERROR: sw expect three arguments";
				throw error;
			}
			if ((tokLines[i][token+1]->getKind() != ASM::REGISTER) || (tokLines[i][token+2]->getKind() != ASM::COMMA) ||
			    ((tokLines[i][token+3]->getKind() != ASM::INT) && (tokLines[i][token+3]->getKind() != ASM::HEXINT)) ||
			    (tokLines[i][token+4]->getKind() != ASM::LPAREN) || (tokLines[i][token+5]->getKind() != ASM::REGISTER) ||
			    (tokLines[i][token+6]->getKind() != ASM::RPAREN)){
				string error = "ERROR: calling sw with wrong peremeter";
				throw error;
			}
			else{	
				unsigned int regist1 = tokLines[i][token+1]->toInt();
				unsigned int regist2 = tokLines[i][token+5]->toInt();
				int num;
				unsigned int hexnum;
				if (tokLines[i][token+3]->getKind() == ASM::INT) {
					num = tokLines[i][token+3]->toInt();
					if ((num > 32769) || (num < -32768)) {
						string error = "ERROR: out of range";
						throw error;
					}
					add = (43 << 26) | (regist2 << 21) | (regist1 << 16) | (num&0xffff);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
					c = add;
					std::cout << c;
				}
				else if (tokLines[i][token+3]->getKind() == ASM::HEXINT) {
					hexnum = tokLines[i][token+3]->toInt();
					if (hexnum > 0xffff){
						string error = "ERROR: out of range";
						throw error;
					}
					add = (43 << 26) | (regist2 << 21) | (regist1 << 16) | (hexnum);
					unsigned char c;
					c = add >> 24;
					std::cout << c;
					c = add >> 16;
					std::cout << c;
					c = add >> 8;
					std::cout << c;
					c = add;
					std::cout << c;
				}
			}
		}

//add functions here
		else {
			string error = "ERROR: Invalud command";
			throw error;
		}
	}
/*	
    // Iterate over the lines of tokens and print them
    // to standard error
    vector<vector<Token*> >::iterator it;
    for(it = tokLines.begin(); it != tokLines.end(); ++it){
      vector<Token*>::iterator it2;
      for(it2 = it->begin(); it2 != it->end(); ++it2){
        cerr << "  Token: "  << *(*it2) << endl;
      }
    }
*/
  } catch(const string& msg){
    // If an exception occurs print the message and end the program
    cerr << msg << endl;
  }
  // Delete the Tokens that have been made
  vector<vector<Token*> >::iterator it;
  for(it = tokLines.begin(); it != tokLines.end(); ++it){
    vector<Token*>::iterator it2;
    for(it2 = it->begin(); it2 != it->end(); ++it2){
      delete *it2;
    }
  }
}
